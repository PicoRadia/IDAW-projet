async function test(number){
    let URL = "https://us.openfoodfacts.org/api/v0/product/" + number;
    const response = await fetch(URL);
    const dataPromise = await response.json(); 
    //status code of a call where there is no product found is 0, therefore in that case set states to empty string and exit
        if(dataPromise.status===0){
            setDataURL("");
            setDataIngredients("");
            setDataNutrition("");
            return
        } 
        console.log(dataPromise.product.nutriments);
          
            
    }
    
test('04963406');
