<?php 
    include 'nav.php';
?>

<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
<div class="container">
        <div class="header clearfix">
            <h3 class="text-muted">Welcome,<br></h3>
        </div>
        <center>
            <div class="jumbotron"><img src="images/lfabresse.jpg" width="140" height="140" border="0"
                    class="rounded-circle">
                <?php 
                  $first_name = "luc";
                  $last_name = "fabresse";
                  echo "<h3> $first_name  $last_name </h3>";
                ?>

                <p class="lead">Go to add diary to add a meal to your food diary .</p>
                <p class="lead">Remember what can't be tracked , can't be managed.</p>
                <p><a class="btn btn-lg btn-success" href="aliments.php" role="button">Food diary</a></p>

                <div class="row marketing">
                    <div class="col-lg-6">
                    </div>

        </center>
    </div>

</div>

<style>
#admin-main-control{
  padding-top:40px;
}


</style>

</body>

<?php 
    include 'footer.php';
?>