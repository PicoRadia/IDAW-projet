<?php
include 'nav.php';
include 'config.php';
?>

<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
    <div class="content-title m-x-auto">
        <div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
            <div class="content-title m-x-auto">
            </div>
            <br>
            <p class="display-4 text-center">Add a meal</p>
            </p>
            <br><br>
            <form action="add-meal.php" method="post">
                <div class="form-group col-sm-5">
                    <label for="lname">Meal's name</label>
                    <input type="meal_name" class="form-control" id="meal-name" placeholder="meal-name">
                </div>
                <div class="form-row">
                    <div class="form-group col-sm-6">
                        <label for="date">Date</label>
                        <input type="date_intake" id="date" class="form-control" value="2021-30-01">
                    </div>
                    <div class="form-group col-sm-6">
                        <label for="myTime2">Time of intake</label>
                        <input id="houre_intake" class="form-control" type="time" min="9:00" max="18:00" value="13:07">
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <br>
                                <p>Type of meal</p>
                                <div class="btn-group btn-group-lg" role="group">

                                    <button id ="breakfast" class="btn btn-secondary" type="button" onclick="$_POST['breakfast']">
                                        Breakfast
                                    </button>
                                    <button id ="lunch" class="btn btn-secondary" type="button" onclick="$_POST['lunch']">
                                        Lunch
                                    </button>
                                    <button id ="dinner" class="btn btn-secondary" type="button" onclick="$_POST['dinner']">
                                        Dinner
                                    </button>

                                </div>
                            </div>
                        </div>
                    </div>
                    <br>

                    <div class="form-group ">
                        <br>
                        <label class="text-center" for="age">category</label>
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="btn-group btn-group-lg" role="group">

                                        <button id="meat" class="btn btn-secondary" type="button">
                                            Meat
                                        </button>
                                        <button id="fish" class="btn btn-secondary" type="button">
                                            Fish
                                        </button>
                                        <button id="drink" class="btn btn-secondary" type="button">
                                            Drink
                                        </button>
                                        <button id="vegetable" class="btn btn-secondary" type="button">
                                            Vegetable
                                        </button>
                                        <button id="desert" class="btn btn-secondary" type="button">
                                            Desert
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                        <h4>Enter the details of the meal in gramms (g).</h4>
                        <div class="row">
                            <div class="form-group col-sm-3">
                                <label for="lname">Fat</label>
                                <input stype="lname" class="form-control" id="fat" placeholder="fat">
                            </div>
                            <div class="form-group col-sm-5">
                                <label for="lname">Saturated fat</label>
                                <input type="lname" class="form-control" id="saturated-fat" placeholder="saturated-fat">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="lname">Sugars</label>
                                <input type="lname" class="form-control" id="sugars" placeholder="sugars">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="lname">Salt</label>
                                <input type="lname" class="form-control" id="salt" placeholder="satlt">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="lname">Serving size</label>
                                <input type="lname" class="form-control" id="serving-size" placeholder="serving-size">
                            </div>
                        </div>

                        <br>
                        <center>
                            <button type="submit" class="btn btn-success">Add meal</button>
            </form>
        </div>


        <!-- element added alert-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-success alert-dismissable">

                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                            ×
                        </button>
                        <h4>
                            Alert!
                        </h4> <strong>Added Meal</strong> Successfully added the meal to your food diary!. <a href="journal.php" class="alert-link">Food diary</a>
                    </div>
                </div>
            </div>
        </div>


    </div>

</div>
</div>
</div>
</div>
</body>

<?php
include 'footer.php';
?>