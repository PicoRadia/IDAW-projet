<?php 
include 'header.php';
include '404.php';
?>
<div class="container-fluid">
    <div class="row">
        <div id="admin-sidebar" class="col-md-2 p-x-0 p-y-3">
            <div class="logo">
                <a href="../../index.html" title="Retour à l'accueil"><img style="width: 180px;" src="./images/iMM.png" >
                </a>
            </div>
            <ul class="sidenav admin-sidenav list-unstyled">
                <li><a href="profile.php">Profile</a></li>
                <li><a href="aliments.php">Add a meal</a></li>
                <li><a href="journal.php">Food Diary</a></li>
                <li><a href="recommendations.php">Recommendations</a></li>
                <li><a href="../../index.html">Home</a></li>
            </ul>
        </div>

  
    
<!-- /#admin-sidebar -->