<?php
// include left navbar
include 'navlogin.php';
?>



<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">

    <h1 class="text-center display-4">Log in</h1>

    <br><br><br>
    <div class="login">
        <div class="row">
            <div class="col-sm">
                <img src="../frontend/images/iMM.png" style="height:350px;">
            </div>
            <div class="col-sm">
                <form id= "myform" action="../backend/welcome.php"  method="post" onsubmit="return results()">
                    <div class="form-group">
                        <label for="myEmail" type="email" >Email</label>
                        <input type="email" name="myEmail" class="form-control " placeholder="Email" value="<?php echo $myEmail;?>"><br>
                        <label for="myPassword">Password</label>
                        <input type="password" name="myPassword" class="form-control " placeholder="Password" value="<?php echo $myPassword;?>">
                        <br>
                        <button style="background-color: #2E8B57;" type="submit" class="btn btn-primary" >Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script> 
// form validation 
function results(){  
var email=document.getElementById('myEmail').value;  
var password=document.getElementById('myPassword').value;  
  
if (email==null || password==""){  
  alert("Field can't be blank");  
  return false;  
}else if(password.length<3){  
  alert("Password must be at least 3 characters long.");  
  return false;  
  }  
}  
</script>  







<style>
footer {
    position: absolute;
}
</style>
<?php
    include 'footer.php';
    ?>
<style>
    #admin-main-control{
        padding-top: 50px;
        padding-right:50px ;
    }
</style>
