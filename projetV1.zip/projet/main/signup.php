<?php 

include 'navlogin.php';

?>

<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
    <div class="content-title m-x-auto">
        
    </div>
    <p class="display-4">Sign up</p>
    
    </p>
    <br><br>
    <form action="add-user.php" method="post">
            <div class="form-row">
               <div class="form-group col-sm-6">
                  <label for="myEmail">Email</label>
                  <input  class="form-control"
                     id="email" placeholder="Email">
               </div>

               <div class="form-group col-sm-6">
                  <label for="myPassword">Password</label>
                  <input type="password" class="form-control"
                     id="mdp" placeholder="Password">
               </div>
                </div>
               <div class="form-row">
               <div class="form-group col-sm-2">
               <label for="mySelect1">Gender</label>
               <select id="gender" class="form-control">
                  <option value="css">Ms</option>
                  <option value="bootstrap" selected>Mr</option>
               </select>
               </div>
               <div class="form-group col-sm-5">
                  <label for="fname">First name</label>
                  <input type="text" class="form-control"
                     id="first_name" placeholder="First name">
               </div>
               <div class="form-group col-sm-5">
                  <label for="lname">Last name</label>
                  <input type="lname" class="form-control"
                     id="last_name" placeholder="Last name">
               </div>
               </div>
               <div class="form-row">
               <div class="form-group col-sm-6">
                  <label for="height">Height (m)</label>
                  <input type="text" class="form-control"
                     id="user_height" placeholder="Height">
               </div>
               <div class="form-group col-sm-6">
                  <label for="weight">Weight (Kg)</label>
                  <input type="text" class="form-control"
                     id="weight" placeholder="Weight">
               </div>
             </div>
             <div class="form-row">
               <div class="form-group col-sm-6">
                  <label for="date">Date of birth</label>
                  <input type="date" id="dob" class="form-control"
      value="1998-05-24">
               </div>

               <div class="form-group col-sm-6">
                  <label for="age">Age category</label>
                  <input type="text" class="form-control"
                     id="category" placeholder="Age category ex : 20>..>30">
               </div>
             </div>
            <div class="form-group">
               <label for="inputAddress">Address</label>
               <input type="text" class="form-control"
                  id="user_address1" placeholder="1234 Main St">
            </div>
            <div class="form-group">
               <label for="inputAddress2">Address 2</label>
               <input type="text" class="form-control"
                  id="user_address1" placeholder="Apartment, studio, or floor">
            </div>
            <div class="form-row">
               <div class="form-group col-sm-6">
                  <label for="myCity">City</label>
                  <input type="text" class="form-control" id="city">
               </div>
               
               <div class="form-group col-sm-2">
                  <label for="myZip">Zip</label>
                  <input type="text" class="form-control" id="zip">
               </div>
            </div>
            <button type="submit" name="reg_user" class="btn btn-primary">Sign up</button>
            <br><br>
            <br><br>
         </form>
</div>
</div>
</div>
       
         </body>
         <br><br>
</body>

<br><br>

</html>

<?php 
    include 'footer.php';
?>