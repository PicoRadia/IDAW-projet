<?php ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>iManger Mieux</title>
    <meta name="author" content="Radia EL HAMDOUNI and Fatima  MASLOUHI">
    <meta name="description" content="iMM food intake web app">
    <meta name="viewport" content="width=device-width, initial-scale=1">



    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="css/nav.css" rel="stylesheet" />
    <link href="css/footer.css" rel="stylesheet" />
    <link id="pagestyle" href="css/light.min.css" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.css">

    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.js">
    </script>
    <!--
  <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
  -->

    <script type="text/javascript" src="js/swipemode.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet" />

</head>


<body>
    <!-- footer -->
    <div id="header">
        <div class="row ">
            <div class="col">
                <div style="padding-left: 10px;">
                    <p> iMangerMieux</p>
                </div>
            </div>
            <div class="col"  ">
              <p style="position:relative; left:650px; bottom:2px;">Change mode</p>
            </div>
            <div class="col">
            <div class="material-switch pull-right">
                  <input id="someSwitchOptionDefault" name="someSwitchOption001" type="checkbox" onclick="switchMode()"/>
                  <label for="someSwitchOptionDefault" class="label-default"></label>
              </div>
            </div>

        </div>

    </div>
    <style>
    #header {
        background-color: #8BC34A;
        color: #ffffff;
        position: relative;
        left: 0px;
        top: 0px;
        height: 40px;
        width: 100%;

    }
    </style>
    <style>
    .material-switch>input[type="checkbox"] {
        display: none;
    }

    .material-switch>label {
        cursor: pointer;
        height: 0px;
        position: relative;
        width: 40px;
    }

    .material-switch>label::before {
        background: rgb(0, 0, 0);
        box-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);
        border-radius: 8px;
        content: '';
        height: 16px;
        margin-top: -8px;
        position: absolute;
        opacity: 0.3;
        transition: all 0.4s ease-in-out;
        width: 40px;
    }

    .material-switch>label::after {
        background: rgb(255, 255, 255);
        border-radius: 16px;
        box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
        content: '';
        height: 24px;
        left: -4px;
        margin-top: -8px;
        position: absolute;
        top: -4px;
        transition: all 0.3s ease-in-out;
        width: 24px;
    }

    .material-switch>input[type="checkbox"]:checked+label::before {
        background: inherit;
        opacity: 0.5;
    }

    .material-switch>input[type="checkbox"]:checked+label::after {
        background: inherit;
        left: 20px;
    }
    </style>