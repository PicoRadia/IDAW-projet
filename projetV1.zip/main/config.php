<?php
$mysqli = new mysqli('localhost','example_user', 'password','imm');

// Check connection
if ($mysqli -> connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
    exit();
}
?>