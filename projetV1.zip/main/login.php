
<?php
include 'navlogin.php';
?>


<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">

    <h1 class="text-center display-4">Log in</h1>

    <br><br><br>
    <div class="login">
        <div class="row">
            <div class="col-sm">
                <img src="../images/iMM.png" style="height:350px;">
            </div>
            <div class="col-sm">
                <form action="check-login.php" method="post">
                    <div class="form-group">
                        <label for="myEmail">Email</label>
                        <input type="email" id="myEmail" class="form-control " placeholder="Email"><br>
                        <label for="myPassword">Password</label>
                        <input type="password" id="myPassword" class="form-control " placeholder="Password">
                        <br>
                        <button style="background-color: #2E8B57;" type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>
<?php
    include 'footer.php';
    ?>
<style>
    #admin-main-control{
        padding-top: 50px;
        padding-right:50px ;
    }
footer {
    position: absolute;
}
</style>