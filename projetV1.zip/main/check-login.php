<?php
// Initialize the session
session_start();

// initializing variables    
    $db = mysqli_connect('localhost','example_user', 'password','imm');
    $errors = array(); 


    // initializing variables
    $email = "";
    $mdp    = ""; 
    // by adding (array_push()) corresponding error unto $errors array
    if (empty($email)) { array_push($errors, "Email is required"); }
    if (empty($mdp)) { array_push($errors, "Password is required"); }
    if (count($errors) == 0) {
        
            // Prepare a select statement
            $sql = "SELECT  mdp FROM USER WHERE email = ?";
            mysqli_stmt_bind_param($stmt, "s", $email);
             // Set parameters
             $param_username = $email;
               // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                           
                            // Redirect user to welcome page
                            header("location: index.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        }
                    }

                }}}
?>