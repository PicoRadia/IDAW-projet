<?php
include 'nav.php';
include 'config.php';
?>

<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
    <div class="content-title m-x-auto">
        <div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
            <br>
            <p class="display-4 text-center">Add a meal</p>
            </p>
            <br><br>
            <div>
                <center>
                    <h3 class= "text-center">Smart Add</h3>
                    <p>Using open food API to extract relevant information</p>
                </center>
            </div>


            <form action="add-meal.php" method="post">
                <div class="form-group col-sm-5">
                    <label for="lname">Meal's name</label>
                    <input type="meal_name" class="form-control" id="meal-name" placeholder="meal-name">
                </div>
                <div class="form-row">
                    <div class="form-group col-sm-6">
                        <label for="date">Date</label>
                        <input type="date_intake" id="date" class="form-control" value="2021-30-01">
                    </div>
                    <div class="form-group col-sm-6">
                        <label for="myTime2">Time of intake</label>
                        <input id="houre_intake" class="form-control" type="time" min="9:00" max="18:00" value="13:07">
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <div lass="col-sm-6">
                                <label class="text-center" for="age"> Type of meal : </label>
                                <select class="form-select" aria-label="Default select example">
                                    <option selected >Breakfast</option>
                                    <option value="1">Lunch</option>
                                    <option value="2">Dinner</option>
                                </select>
                            </div>
                        </div>

                        <br>

                        <div class="form-group ">
                            <br>
                            <div lass="col-sm-6">
                                <label class="text-center" for="age">category</label>
                                <select class="form-select" aria-label="Default select example">
                                    <option selected>Meat</option>
                                    <option value="1">Fish</option>
                                    <option value="2">Drink</option>
                                    <option value="3">Vegetable</option>
                                    <option value="3">Desert</option>
                                </select>
                            </div>
                            <br>
                            <h4>Enter the details of the meal in gramms (g).</h4>
                            <div class="row">
                                <div class="form-group col-sm-3">
                                    <label for="lname">Fat</label>
                                    <input stype="lname" class="form-control" id="fat" placeholder="fat">
                                </div>
                            </div>
                        </div>


                            <div class="form-group col-sm-5">
                                <label for="lname">Saturated fat</label>
                                <input type="lname" class="form-control" id="saturated-fat" placeholder="saturated-fat">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="lname">Sugars</label>
                                <input type="lname" class="form-control" id="sugars" placeholder="sugars">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="lname">Salt</label>
                                <input type="lname" class="form-control" id="salt" placeholder="satlt">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="lname">Serving size</label>
                                <input type="lname" class="form-control" id="serving-size" placeholder="serving-size">
                            </div>
                        </div>

                        <br>
                        <center>
                            <button type="submit" class="btn btn-success">Add meal</button>
                        </center>
            </form>
        </div>


        <!-- element added alert-->
        <div class="container-fluid">
            <div class="row">
                
                </div>
            </div>
        </div>


       <br><br>

    </div>

</div>
</div>
</div>
</div>
</body>

<?php
include 'footer.php';
?>