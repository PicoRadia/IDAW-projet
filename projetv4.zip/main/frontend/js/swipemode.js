function switchMode(){
        var element = document.getElementById("pagestyle");
        if(element.getAttribute('href') == "css/light.min.css"){
          
                element.setAttribute('href', 'css/dark.min.css');
        }
        else{
                element.setAttribute('href', 'css/light.min.css');
        }
       

}


