CREATE DATABASE imm ;
USE imm;
CREATE USER 'example_user'@'%' IDENTIFIED WITH mysql_native_password BY 'password';
GRANT ALL ON imm.* TO 'example_user'@'%';



''' Creation de la table USER '''
CREATE TABLE USER
(
    id INT PRIMARY KEY  NOT NULL AUTO_INCREMENT ,
    last_name VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    mdp VARCHAR(100) NOT NULL,
    email VARCHAR(80) NOT NULL,
    gender char(1),
    user_weight  VARCHAR(10) ,
    user_height  VARCHAR(10) ,
    dob DATE ,
    category char(1) ,
    user_address1 VARCHAR(100),
    user_address2 VARCHAR(100) ,
    city VARCHAR(255) ,
    zip VARCHAR(5)
);



''' Insertion dans la table user '''
INSERT INTO USER(last_name,first_name,mdp,email,gender,category) Values
(
    'fabresse',
    'luc',
    'root',
    'luc.fabresse@imt-lille-douai.fr',
    'M',
    '2'
);

INSERT INTO USER(last_name,first_name,mdp,email,gender,category) Values
(
    'Maslouhi',
    'Fatima',
    'root',
    'fatima.maslouhi@etu.imt-lille-douai.fr',
    'F',
    '1'

    
);

INSERT INTO USER(last_name,first_name,mdp,email,gender,category) Values
(
    'el hamdouni',
    'radia',
    'root',
    'radia.el.hamdouni@etu.imt-lille-douai.fr',
    'F',
    '1'
    
);


''' Creation de la table USER '''
CREATE TABLE MEAL
(
    id_meal INT PRIMARY KEY  NOT NULL AUTO_INCREMENT ,
    meal_name VARCHAR(100) NOT NULL,
    date_intake DATE,
    hour_intake VARCHAR(100) ,
    type_meal VARCHAR(80) ,
    category_meal  VARCHAR(20) ,
    fat  VARCHAR(100) ,
    protein  VARCHAR(100) ,
    saturated_fat  VARCHAR(100) ,
    sugars VARCHAR(100) ,
    salt VARCHAR(100),
    serving_size VARCHAR(100),
    user_id INT,  
    CONSTRAINT fk_user FOREIGN KEY (user_id)  
    REFERENCES USER(id)  
    ON DELETE CASCADE  
    ON UPDATE CASCADE     
);

''' Code insertion dans la table meal'''
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) Values(
    'coca-cola',
    STR_TO_DATE('1-01-2012', '%d-%m-%Y'),
    '03:13',
    'lunch',
    'drink',
    '0',
    '0',
    '0',
    '10.6',
    '0',
    '100',
    1
);
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) Values(
    'nutella',
    STR_TO_DATE('1-01-2021', '%d-%m-%Y'),
    '03:18',
    'brakfast',
    'desert',
    '0',
    '0',
    '0',
    '20.6',
    '0',
    '80',
    1
);

INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) Values(
    'coca-cola',
    STR_TO_DATE('1-01-2012', '%d-%m-%Y'),
    '03:13',
    'lunch',
    'drink',
    '0',
    '0',
    '0',
    '10.6',
    '0',
    '100',
    1
);

''' Code insertion dans la table meal'''
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) Values(
    'meat balls',
    STR_TO_DATE('1-01-2021', '%d-%m-%Y'),
    '05:13',
    'lunch',
    'meat',
    '100',
    '20',
    '0.6',
    '0',
    '0',
    '300',
    1
);

''' Code insertion dans la table meal'''
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) Values(
    'carrots',
    STR_TO_DATE('1-03-2021', '%d-%m-%Y'),
    '03:13',
    'dinner',
    'vegetable',
    '0',
    '0',
    '0',
    '0.6',
    '0.3',
    '100',
    1
);


