<?php
      echo "Welcome ". $_POST['breakfast']. "<br />";

?>