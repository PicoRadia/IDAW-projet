<?php
// Starting session
session_start();
$con = mysqli_connect('localhost','example_user', 'password','imm');
$response = array();
$user_id = $_SESSION['id'];


if($con){
    $sql = "SELECT * FROM MEAL INNER JOIN USER   WHERE USER.id = $user_id ";
    $result = mysqli_query($con,$sql);
    if($result){
        header("Content-Type:JSON");
        $i=0;
        while($row = mysqli_fetch_assoc($result)){
            //$response[$i]['id_meal'] = $row ['id_meal'];
            $response[$i]['meal_name'] = $row ['meal_name'];
            $response[$i]['date_intake'] = $row ['date_intake'];
            $response[$i]['houre_intake'] = $row ['houre_intake'];
            $response[$i]['type_meal'] = $row ['type_meal'];
            $response[$i]['category_meal'] = $row ['category_meal'];
            $response[$i]['fat'] = $row ['fat'];
            $response[$i]['protein'] = $row ['protein'];
            $response[$i]['saturated_fat'] = $row ['saturated_fat'];
            $response[$i]['sugars'] = $row ['sugars'];
            $response[$i]['salt'] = $row ['salt'];
            $response[$i]['serving_size'] = $row ['serving_size'];
            $i++;
        }
        echo json_encode($response,JSON_PRETTY_PRINT);
    }
}
else 
{
    echo "Database connexion failed";
}
?>