<?php
 // Starting session
 session_start();
include 'nav.php';

?>

<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
    <div class="content-title m-x-auto">
        <div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
            <br>
            <p class="display-4 text-center">Add a meal</p>
            </p>
            <br><br>
            <div>
                <center>
                    <h3 class= "text-center">Smart Add</h3>
                    <p>Using open food API to extract relevant information</p>
                </center>
            </div>


          


        <!-- element added alert-->
        <div class="container-fluid">
            <div class="row">
                
                </div>
            </div>
        </div>


       <br><br>

    </div>

</div>
</div>
</div>
</div>
</body>

<?php
include 'footer.php';
?>