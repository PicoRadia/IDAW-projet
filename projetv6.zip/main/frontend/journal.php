<?php 
    include 'nav.php';
    
?>
<script>
    async function getresults(){
        let URL = "../backend/api/all-meals.php" ;
        const response = await fetch(URL);
        const dataPromise = await response.json(); 
        console.log(dataPromise);
        return dataPromise;

         
    }
    var result = getresults();

</script>


<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
    <div class="content-title m-x-auto">
        
    </div>
    <div class="mx-auto" style="height:50px;"></div>
    <p class="display-4 text-center">History of food intake</p>
   
	
<table id="table_id" class="display">
    <thead>
        <tr>
            <th>Name</th>
            <th>Date</th>
            <th>Hour</th>
            <th>Type</th>
            <th>category</th>
            <th>Fat</th>
            <th>Protein</th>
            <th>saturated fat</th>
            <th>sugars</th>
            <th>salt</th>
            <th>serving size</th>
            <th>Delete</th>


        </tr>
    </thead>
   
</table>
</body>

</div></div>
<script>
$(document).ready( 
function () {
    $('#table_id').DataTable({
        "serverSide": true,
         "ajax": {
        "url": '../backend/api/all-meals.php',
        "type": "POST",
        "datatype": "JSON",
    },

        "dataSrc":function (jsonString) {
                       var jsonData = JSON.parse(jsonString);
                       return jsonData.data;
            },
        
        
        "columns": [
            { title: "meal_name" },
            { title: "date_intake" },
            { title: "houre_intake" },
            { title: "type_meal" },
            { title: "fat" },
            { title: "protein" },
            { title: "saturated fat" },
            { title: "sugars" },
            { title: "salt" },
            { title: "serving size" }

        ],
        "columnDefs": [ {
            "targets": -1,
            "data": null,
            "defaultContent": "<button>Click!</button>"
        } ]
    
    
    })
})
</script>


<?php 
    include 'footer.php';
?>