async function test(number){
    let URL = "https://us.openfoodfacts.org/api/v0/product/" + number;
    const response = await fetch(URL);
    const dataPromise = await response.json(); 
    //status code of a call where there is no product found is 0, therefore in that case set states to empty string and exit
        if(dataPromise.status===0){
            setDataURL("");
            setDataIngredients("");
            setDataNutrition("");
            return
        } 
        console.log(dataPromise.product.nutriments);
          
            
    }
    
test('04963406');



async function test2(number){
    let URL = "https://us.openfoodfacts.org/api/v0/product/" + number;
    const response = await fetch(URL);
    const dataPromise = await response.json(); 
    //status code of a call where there is no product found is 0, therefore in that case set states to empty string and exit
        if(dataPromise.status===0){
            setDataURL("");
            setDataIngredients("");
            setDataNutrition("");
            return
        } 
        var obj = {
'image':dataPromise.product.image_front_url,
'sugars':dataPromise.product.nutriments.sugars_100g, 
'protein':dataPromise.product.nutriments.proteins_100g, 
'fat':dataPromise.product.nutriments.fat_100g};
console.log(obj);
          
            
    }
    
test2('04963406');