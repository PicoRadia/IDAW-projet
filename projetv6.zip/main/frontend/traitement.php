<?php
    if(isset($_GET['id_meal'])){

        $response = array();

        $response[$i]['id_meal'] = $_GET ['id_meal'];
        $response[$i]['meal_name'] = $_GET ['meal_name'];
        $response[$i]['date_intake'] = $_GET ['date_intake'];
        $response[$i]['hour_intake'] = $_GET ['hour_intake'];
        $response[$i]['type_meal'] = $_GET ['type_meal'];
        $response[$i]['category_meal'] = $_GET ['category_meal'];
        $response[$i]['fat'] = $_GET ['fat'];
        $response[$i]['saturated_fat'] = $_GET ['saturated_fat'];
        $response[$i]['sugars'] = $_GET ['sugars'];
        $response[$i]['salt'] = $_GET ['salt'];
        $response[$i]['serving_size'] = $_GET ['serving_size'];

        $js = file_get_contents('response.json');

        $js = json_decode($js, true);

        $js = $response;

        $js = json_encode($js);

        file_put_contents('response.json',$js);
    }
?>