<?php
$meal_name = $conn->real_escape_string($_POST['meal_name']);
$date_intake = $conn->real_escape_string($_POST['date_intake']);
$houre_intake = $conn->real_escape_string($_POST['houre_intake']);
$type_meal = $conn->real_escape_string($_POST['type_meal']);
$category_meal = $conn->real_escape_string($_POST['category_meal']);
$fat = $conn->real_escape_string($_POST['fat']);
$saturated_fat = $conn->real_escape_string($_POST['saturated_fat']);
$sugars = $conn->real_escape_string($_POST['sugars']);
$salt = $conn->real_escape_string($_POST['salt']);
$serving_size = $conn->real_escape_string($_POST['serving_size']); 


?>