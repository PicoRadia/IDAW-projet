<?php 
// Starting session
session_start();
    include 'nav.php';
    $mysqli = new mysqli('localhost','example_user', 'password','imm');

    // Check connection
    if ($mysqli -> connect_errno) {
        echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
        exit();
    }
    $result = mysqli_query($mysqli,"SELECT * FROM MEAL");
?>
<?php
  function runMyFunction() {
    echo 'I just ran a php function';
  }

  if (isset($_GET['delete'])) {
    runMyFunction();
  }
?>

<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
    <div class="content-title m-x-auto">
        
    </div>
    <div class="mx-auto" style="height:50px;"></div>
    <p class="display-4 text-center">History of food intake</p>
   
	
<table id="table_id" class="display">
    <thead>
        <tr>
            
            <th>Name</th>
            <th>Date</th>
            <th>Hour</th>
            <th>Type</th>
            <th>category</th>
            <th>Fat</th>
            <th>Protein</th>
            <th>saturated fat</th>
            <th>sugars</th>
            <th>salt</th>
            <th>serving size</th>

        </tr>
    </thead>
    <tbody>
       <?php 
       while($row = mysqli_fetch_array($result))
       {
       echo "<tr>";
       echo "<td>" . $row['meal_name'] . "</td>";
       echo "<td>" . $row['date_intake'] . "</td>";
       echo "<td>" . $row['hour_intake'] . "</td>";
       echo "<td>" . $row['type_meal'] . "</td>";
       echo "<td>" . $row['category_meal'] . "</td>";
       echo "<td>" . $row['fat'] . "</td>";
       echo "<td>" . $row['protein'] . "</td>";
       echo "<td>" . $row['saturated_fat'] . "</td>";
       echo "<td>" . $row['sugars'] . "</td>";
       echo "<td>" . $row['salt'] . "</td>";
       echo "<td>" . $row['serving_size'] . "</td>";
    

       echo "</tr>";
       }
?>
      
    </tbody>
</table>
<script>
function deleteRow(index) {
    rows.splice(index, 1);
    fetchRows(rows);
    // Chaque bouton "supprimer"
    document.querySelectorAll("button.delete").forEach(b => {
    b.addEventListener("click", function() {
      return deleteRow(this.value);
    });
});}

document.querySelectorAll("button.delete").forEach(b => {
    b.addEventListener("click", function() {
      return deleteRow(this.value);
    });
});


</script>




    
<div class="mx-auto" style="height:250px;"></div>
</div></div>
<script>
    $(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
</body>

<?php 
    include 'footer.php';
?>