async function getSalt(){
    let URL = "../backend/api/total.php?type=salt";
    const response = await fetch(URL);
    const dataPromise = await response.json(); 
    //status code of a call where there is no product found is 0, therefore in that case set states to empty string and exit
        if(dataPromise.status===0){
            return
        } 
        console.log(dataPromise);
          
            
    }
getSalt();