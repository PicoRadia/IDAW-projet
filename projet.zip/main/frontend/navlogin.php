<?php 

include 'header.php';

?>
<div class="container-fluid">
    <div class="row">

        <div id="admin-sidebar" class="col-md-2 p-x-0 p-y-3">
            <div class="logo">
                <a href="../../index.html" title="Retour à l'accueil"><img style="width: 180px;" src="./images/iMM.png">
                </a>
            </div>
            <ul class="sidenav admin-sidenav list-unstyled">
                <li><a href="login.php">Sign in</a></li>
                <li><a href="signup.php">Sign up</a></li>
                <li><a href="../index.html">Home</a></li>

            </ul>
        </div> <!-- /#admin-sidebar -->