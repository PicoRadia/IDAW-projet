<?php
// Starting session
session_start();
require_once('../backend/config.php');

 $myEmail = $_POST["myEmail"]; 
 $myPassword = $_POST["myPassword"]; 

 echo "<h1>" . $myEmail . "</h1>";
 $mysql = new mysqli('localhost','example_user', 'password','imm');
 echo "<h1>hello</h1>";

$sql = "SELECT * FROM USER where  email='$myEmail'";

$res = $mysql->query($sql);
while (NULL !== ($row = $res->fetch_array())) {
    $mdp =  $row['mdp'];
    $_SESSION['first_name'] = $row['first_name'];
    $_SESSION['last_name'] = $row['last_name'];
    $_SESSION['id']  = $row['id'];

} 

 
if($mdp == $myPassword){
 header("Location: ./profile.php");
}
else{
    header("Location: ./login.php");
}

?>