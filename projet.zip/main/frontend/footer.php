 <!-- footer -->
 <footer id="footer">
            <div class="row ">
                <div class="col">
                    <div class=" text-center ">

                        &copy; Copyright, 2021 - IMT Lille Douai - IDAW - iMangerMieux<a href="../backend/doc/RESTAPI.html"> iMM API Documentation</a>
                        and <a href="../backend/api/all-meals.php"> Quick access to the API </a>

                    </div>
                </div>

            </div>
   
    </footer>
    <style>
    body {
        margin: 0;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }
   
        footer {
            background-color: #8BC34A;
	    color: #ffffff;
            position: relative;
            left: 0;
            bottom: 0;
            height: 40px;
            width: 100%;
            overflow: hidden;
        }

    </style>