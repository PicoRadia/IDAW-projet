<?php
include 'nav.php';
// Starting session
session_start();

function add_meal(){
    $con = mysqli_connect('localhost','example_user', 'password','imm');
    $meal_name =   $_GET['meal_name'];
    $date_intake = $_GET["date_intake"];
    $hour_intake = $_GET["hour_intake"];
    $type_meal =   $_GET["type_meal"];
    $category_meal=$_GET["category_meal"];
    $fat=          $_GET["fat"];
    $saturated_fat=$_GET["saturated_fat"];
    $sugars =      $_GET["sugars"];
    $salt=         $_GET["salt"];
    $serving_size= $_GET["serving_size"];

    //On insère les données reçues
    $sql ="INSERT INTO MEAL(meal_name, date_intake, hour_intake, type_meal, category_meal, fat, saturated_fat, sugars, salt, serving_size) VALUES($meal_name, $date_intake, $hour_intake, $type_meal, $category_meal, $fat, $saturated_fat, $sugars, $salt, $serving_size)";
    mysqli_query($con,$sql);   
}
?>

<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
    <div class="content-title m-x-auto">
        <div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
            <br>
            <p class="display-4 text-center">Add a meal</p>
            </p>
            <br><br>
            

            <form action="<?php add_meal() ?>" method="get">
                <div class="form-group col-sm-5">
                    <label >Meal's name</label>
                    <input name="meal_name" class="form-control" id="meal_name" placeholder="meal-name">
                </div>
                <div class="form-row">
                    <div class="form-group col-sm-6">
                        <label for="date">Date</label>
                        <input  name="date_intake" id="date" class="form-control" value="2021-30-01">
                    </div>
                    <div class="form-group col-sm-6">
                        <label for="myTime2">Time of intake</label>
                        <input name="hour_intake" class="form-control" type="time" min="9:00" max="18:00" value="13:07">
                    </div>
                        <br>
                            <div class="form-group col-sm-5">
                                <label >Category</label>
                                <input   class="form-control" name="category_meal" placeholder="Category">
                            </div>
                            <div class="form-group col-sm-5">
                                <label>Type</label>
                                <input  class="form-control" name="type_meal" id="type" placeholder="Type">
                            </div>
                            <div class="form-group col-sm-5">
                                <label >Saturated fat</label>
                                <input   class="form-control" name="saturated_fat" placeholder="Saturated-fat">
                            </div>
                            <div class="form-group col-sm-5">
                                <label >Fat</label>
                                <input   class="form-control" name="fat" placeholder="Fat">
                            </div>
                            <div class="form-group col-sm-3">
                                <label >Sugars</label>
                                <input   class="form-control" name="sugars" placeholder="Sugars">
                            </div>
                            <div class="form-group col-sm-6">
                                <label >Salt</label>
                                <input   class="form-control" name="salt" placeholder="Satlt">
                            </div>
                            <div class="form-group col-sm-6">
                                <label >Serving size</label>
                                <input   class="form-control" name="serving_size" placeholder="Serving-size">
                            </div>
                        </div>

                        <br>
                        <center>
                            <button type="submit" class="btn btn-success">Add meal</button>
                        </center>
            </form>
        </div>


        <!-- element added alert-->
        <div class="container-fluid">
            <div class="row">
                
                </div>
            </div>
        </div>


       <br><br>

    </div>

</div>
</div>
</div>
</div>
</body>

<?php
include 'footer.php';
?>