CREATE DATABASE imm ;
USE imm;
CREATE USER 'example_user'@'%' IDENTIFIED WITH mysql_native_password BY 'password';
GRANT ALL ON imm.* TO 'example_user'@'%';



''' Creation de la table USER '''
CREATE TABLE USER
(
    id INT PRIMARY KEY  NOT NULL AUTO_INCREMENT ,
    last_name VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    mdp VARCHAR(100) NOT NULL,
    email VARCHAR(80) NOT NULL,
    gender char(1),
    user_weight  VARCHAR(10) ,
    user_height  VARCHAR(10) ,
    dob DATE ,
    category char(1) ,
    user_address1 VARCHAR(100),
    user_address2 VARCHAR(100) ,
    city VARCHAR(255) ,
    zip VARCHAR(5)
);



''' Insertion dans la table user '''
INSERT INTO USER(last_name,first_name,mdp,email,gender,category) Values
(
    'fabresse',
    'luc',
    'root',
    'luc.fabresse@imt-lille-douai.fr',
    'M',
    '2'
);

INSERT INTO USER(last_name,first_name,mdp,email,gender,category) Values
(
    'Maslouhi',
    'Fatima',
    'root',
    'fatima.maslouhi@etu.imt-lille-douai.fr',
    'F',
    '1'

    
);

INSERT INTO USER(last_name,first_name,mdp,email,gender,category) Values
(
    'el hamdouni',
    'radia',
    'root',
    'radia.el.hamdouni@etu.imt-lille-douai.fr',
    'F',
    '1'
    
);


''' Creation de la table USER '''
CREATE TABLE MEAL
(
    id_meal INT PRIMARY KEY  NOT NULL AUTO_INCREMENT ,
    meal_name VARCHAR(100) NOT NULL,
    date_intake DATE,
    hour_intake VARCHAR(100) ,
    type_meal VARCHAR(80) ,
    category_meal  VARCHAR(20) ,
    fat  VARCHAR(100) ,
    protein  VARCHAR(100) ,
    saturated_fat  VARCHAR(100) ,
    sugars VARCHAR(100) ,
    salt VARCHAR(100),
    serving_size VARCHAR(100),
    user_id INT,  
    CONSTRAINT fk_user FOREIGN KEY (user_id)  
    REFERENCES USER(id)  
    ON DELETE CASCADE  
    ON UPDATE CASCADE     
);

''' Code insertion dans la table meal'''
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) Values(
    'coca-cola',
    STR_TO_DATE('1-01-2012', '%d-%m-%Y'),
    '03:13',
    'lunch',
    'drink',
    '0',
    '0',
    '0',
    '10.6',
    '0',
    '100',
    1
);
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) Values(
    'nutella',
    STR_TO_DATE('1-01-2021', '%d-%m-%Y'),
    '03:18',
    'brakfast',
    'desert',
    '0',
    '0',
    '0',
    '20.6',
    '0',
    '80',
    1
);

INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) Values(
    'coca-cola',
    STR_TO_DATE('1-01-2012', '%d-%m-%Y'),
    '03:13',
    'lunch',
    'drink',
    '0',
    '0',
    '0',
    '10.6',
    '0',
    '100',
    1
);

''' Code insertion dans la table meal'''
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) Values(
    'meat balls',
    STR_TO_DATE('1-01-2021', '%d-%m-%Y'),
    '05:13',
    'lunch',
    'meat',
    '100',
    '20',
    '0.6',
    '0',
    '0',
    '300',
    1
);

''' Code insertion dans la table meal'''
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) Values(
    'carrots',
    STR_TO_DATE('1-03-2021', '%d-%m-%Y'),
    '03:13',
    'dinner',
    'vegetable',
    '0',
    '0',
    '0',
    '0.6',
    '0.3',
    '100',
    1
);

INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) VALUES
(   'carrots',
    STR_TO_DATE('03 -04-2021', '%d-%m-%Y'),
    '02:15',
    'dinner',
    'vegetable',
    '0',
    '0',
    '0',
    '0.6',
    '0.3',
    '100',
    1
),
(  'apple juice',
    STR_TO_DATE('03 -04-2021', '%d-%m-%Y'),
    '03:17',
    'breakfast',
    'drink',
    '10',
    '0',
    '30',
    '0.6',
    '0.3',
    '100',
    1
);
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) VALUES
(   'bread',
    STR_TO_DATE('04 -04-2021', '%d-%m-%Y'),
    '5:15',
    'dinner',
    'other',
    '10',
    '0',
    '20',
    '0.6',
    '0.3',
    '300',
    1
),
(  'coffee',
    STR_TO_DATE('04 -04-2021', '%d-%m-%Y'),
    '03:17',
    'breakfast',
    'drink',
    '0',
    '0',
    '30',
    '0.6',
    '0',
    '50',
    1
);
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) VALUES
(   'salad',
    STR_TO_DATE('04 -04-2021', '%d-%m-%Y'),
    '05:15',
    'lunch',
    'other',
    '10',
    '50',
    '20',
    '500',
    '0.3',
    '700',
    1
),
(  'milk',
    STR_TO_DATE('06 -04-2021', '%d-%m-%Y'),
    '09:00',
    'breakfast',
    'drink',
    '0',
    '0',
    '30',
    '0.6',
    '0',
    '30',
    1
);
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) VALUES
(   'soft drink',
    STR_TO_DATE('05 -04-2021', '%d-%m-%Y'),
    '05:15',
    'lunch',
    'drink',
    '10',
    '0',
    '0',
    '50',
    '0',
    '100',
    1
),
(  'sprite',
    STR_TO_DATE('05 -04-2021', '%d-%m-%Y'),
    '09:00',
    'lunch',
    'drink',
    '0',
    '0',
    '30',
    '0.6',
    '0',
    '30',
    1
),
(  'orange juice',
    STR_TO_DATE('05 -04-2021', '%d-%m-%Y'),
    '10:00',
    'brakfast',
    'drink',
    '0',
    '0',
    '30',
    '0.6',
    '0',
    '30',
    1
);
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) VALUES
(   'tajine',
    STR_TO_DATE('02 -04-2021', '%d-%m-%Y'),
    '03:15',
    'lunch',
    'vegetable',
    '100',
    '20',
    '30',
    '50',
    '40',
    '1000',
    1
),
(  'tea',
    STR_TO_DATE('02 -04-2021', '%d-%m-%Y'),
    '16:00',
    'lunch',
    'drink',
    '0',
    '0',
    '20',
    '0.6',
    '0',
    '30',
    1
),
(  'ice cream',
    STR_TO_DATE('02 -04-2021', '%d-%m-%Y'),
    '10:00',
    'dinner',
    'desert',
    '12',
    '20',
    '30',
    '6',
    '10',
    '300',
    1
);
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) VALUES
(   'chiken',
    STR_TO_DATE('03 -04-2021', '%d-%m-%Y'),
    '03:15',
    'lunch',
    'meat',
    '200',
    '20',
    '80',
    '50',
    '40',
    '300',
    1
),
(  'coke',
    STR_TO_DATE('03 -04-2021', '%d-%m-%Y'),
    '07:00',
    'dinner',
    'drink',
    '0',
    '0',
    '20',
    '80',
    '0',
    '300',
    1
),
(  'chocolat mik',
    STR_TO_DATE('01 -04-2021', '%d-%m-%Y'),
    '10:00',
    'brakfast',
    'breakfast',
    '12',
    '20',
    '30',
    '06',
    '100',
    '50',
    1
);
INSERT INTO MEAL(meal_name,date_intake,hour_intake,type_meal,category_meal,fat,protein,saturated_fat,sugars,salt,serving_size,user_id) VALUES
(   'sausage',
    STR_TO_DATE('01 -03-2021', '%d-%m-%Y'),
    '03:15',
    'lunch',
    'meat',
    '200',
    '20',
    '80',
    '50',
    '40',
    '600',
    1
),
(  'chiken',
    STR_TO_DATE('30 -03-2021', '%d-%m-%Y'),
    '08:00',
    'dinner',
    'meat',
    '100',
    '20',
    '40',
    '80',
    '0',
    '300',
    1
),
(  'tea',
    STR_TO_DATE('30 -03-2021', '%d-%m-%Y'),
    '10:00',
    'brakfast',
    'drink',
    '2',
    '20',
    '10',
    '06',
    '100',
    '50',
    1
);

