<?php
// Starting session
session_start();
$con = mysqli_connect('localhost','example_user', 'password','imm');
$response = array();
$user_id = $_SESSION['id'];
$type = $_GET['type'];

if($con){
    $sql = " SELECT date_intake, SUM($type)  FROM MEAL WHERE user_id = 1";
    $result = mysqli_query($con,$sql);
    if($result){
        header("Content-Type:JSON");
        $i=0;
        while($row = mysqli_fetch_assoc($result)){
            $response[$i]['date_intake'] = $row ['date_intake'];
            $response[$i][$type] = $row [$type];
            $i++;
        }
        echo json_encode($response,JSON_PRETTY_PRINT);
    }
}
else 
{
    echo "Database connexion failed";
}
?>