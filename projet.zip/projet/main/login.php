<?php
include 'navlogin.php';
?>


<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
    <div class="content-title m-x-auto">

    </div>
    <p class="display-4">Log in</p>

    </p>
</div> <!-- /#admin-main-control -->
</div> <!-- /.row -->
</div> <!-- /.container-fluid -->
<div class="login">
    <form action="check-login.php" method="post">

        <div class="form-group" align="center">
            <label for="myEmail">Email</label>
            <input type="email" id="myEmail" class="form-control col-sm-4" placeholder="Email"><br>
            <label for="myPassword">Password</label>
            <input type="password" id="myPassword" class="form-control col-sm-4" placeholder="Password">
            <br>
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
    <div class="mx-auto" style="height:80px;"></div>

    <?php
    include 'footer.php';
    ?>