<?php
    session_start();
// initializing variables    
    $db = mysqli_connect('localhost','example_user', 'password', 'imm');
    $errors = array(); 


    // initializing variables
    $last_name = "";
    $first_name    = ""; 
    $mdp    = "";
    $email    = ""; 
    $gender    = ""; 
    $user_weight    = ""; 
    $user_height    = ""; 
    $dob    = ""; 
    $category    = ""; 
    $user_address1    = ""; 
    $user_address2    = ""; 
    $city   = ""; 
    $zip   = ""; 

// REGISTER USER
if (isset($_POST['reg_user'])) {
    // receive all input values from the form
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $mdp = mysqli_real_escape_string($db, $_POST['mdp']);
    $gender = mysqli_real_escape_string($db, $_POST['gender']);
   echo "$first_name";
    $first_name = mysqli_real_escape_string($db, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($db, $_POST['last_name']);

    $user_height = mysqli_real_escape_string($db, $_POST['user_height']);
    $user_weight = mysqli_real_escape_string($db, $_POST['user_weight']);
    $dob = mysqli_real_escape_string($db, $_POST['dob']);

    $category = mysqli_real_escape_string($db, $_POST['category']);

    $user_address1 = mysqli_real_escape_string($db, $_POST['user_address1']);
    $user_address2 = mysqli_real_escape_string($db, $_POST['user_address2']);

    $city = mysqli_real_escape_string($db, $_POST['city']);
    $zip = mysqli_real_escape_string($db, $_POST['zip']);
    // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
    if (empty($email)) { array_push($errors, "Email is required"); }
    if (empty($mdp)) { array_push($errors, "Password is required"); }

    if (count($errors) == 0) {
        $password = md5($password_1);//encrypt the password before saving in the database
  
        $query = "INSERT INTO users (last_name, first_name, mdp,email,gender , user_weight ,user_height,dob ,category , user_address1,user_adress2,city,zip ) 
                  VALUES('$last_name', '$first_name','$mdp','$email ', '$gender' , '$user_weight' , '$user_height ', STR_TO_DATE('$dob', '%d-%m-%Y') , '$category' , '$user_address1','$user_adress2','$city','$zip')";
        mysqli_query($db, $query);
        $_SESSION['first_name'] = $first_name;
        $_SESSION['success'] = "You are now logged in";
        header('location: index.php');
    }
    else{
      echo "hola";
    }
  }

    
?>

