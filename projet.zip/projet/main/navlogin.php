<?php 

include 'header.php';

?>
<div class="container-fluid">
        <div class="row">    
            <div id="admin-sidebar" class="col-md-2 p-x-0 p-y-3">
                <ul class="sidenav admin-sidenav list-unstyled">
                    <li><a href="login.php">Sign in</a></li>
                    <li><a href="signup.php">Sign up</a></li>
                    <li><a href="/projet/index.html">Home</a></li>
                                   
                </ul>
</div> <!-- /#admin-sidebar -->