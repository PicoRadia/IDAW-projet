CREATE DATABASE imm ;
USE imm;

''' Creation de la table USER '''
CREATE TABLE USER
(
    id INT PRIMARY KEY  NOT NULL AUTO_INCREMENT ,
    last_name VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    mdp VARCHAR(100) NOT NULL,
    email VARCHAR(80) NOT NULL,
    gender char(1),
    user_weight  VARCHAR(10) ,
    user_height  VARCHAR(10) ,
    dob DATE ,
    category char(1) ,
    user_address1 VARCHAR(100),
    user_address2 VARCHAR(100) ,
    city VARCHAR(255) ,
    zip VARCHAR(5)
);



''' Insertion dans la table user '''
INSERT INTO USER(last_name,first_name,mdp,email) Values
(
    'fabresse',
    'luc',
    'root',
    'luc.fabresse@imt-lille-douai.fr'
);

INSERT INTO USER(last_name,first_name,mdp,email) Values
(
    'Maslouhi',
    'Fatima',
    'root',
    'fatima.maslouhi@etu.imt-lille-douai.fr'
    
);

INSERT INTO user(last_name,first_name,mdp,email) Values
(
    'el hamdouni',
    'radia',
    'root',
    'radia.el.hamdouni@etu.imt-lille-douai.fr'
    
);


''' Creation de la table USER '''
CREATE TABLE MEAL
(
    id_meal INT PRIMARY KEY  NOT NULL AUTO_INCREMENT ,
    meal_name VARCHAR(100) NOT NULL,
    date_intake DATE,
    houre_intake VARCHAR(100) ,
    type_meal VARCHAR(80) ,
    category_meal  VARCHAR(20) ,
    fat  VARCHAR(100) ,
    saturated_fat  VARCHAR(100) ,
    sugars VARCHAR(100) ,
    salt VARCHAR(100),
    serving_size VARCHAR(100) 
    
);

''' Code insertion dans la table meal'''
INSERT INTO MEAL(meal_name,date_intake,houre_intake,type_meal,category_meal,fat,saturated_fat,sugars,salt,serving_size) Values(
    'coca-cola',
    STR_TO_DATE('1-01-2012', '%d-%m-%Y'),
    '03:13',
    'lunch',
    'drink',
    '0',
    '0',
    '10.6',
    '0',
    '100'
);
INSERT INTO MEAL(meal_name,date_intake,houre_intake,type_meal,category_meal,fat,saturated_fat,sugars,salt,serving_size) Values(
    'nutella',
    STR_TO_DATE('1-01-2021', '%d-%m-%Y'),
    '03:18',
    'brakfast',
    'desert',
    '0',
    '0',
    '20.6',
    '0',
    '80'
);

INSERT INTO MEAL(meal_name,date_intake,houre_intake,type_meal,category_meal,fat,saturated_fat,sugars,salt,serving_size) Values(
    'coca-cola',
    STR_TO_DATE('1-01-2012', '%d-%m-%Y'),
    '03:13',
    'lunch',
    'drink',
    '0',
    '0',
    '10.6',
    '0',
    '100'
);

CREATE USER 'example_user'@'%' IDENTIFIED WITH mysql_native_password BY 'password';
GRANT ALL ON imm.* TO 'example_user'@'%';
